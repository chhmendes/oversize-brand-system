---
name: oversize-design
description: Use this skill to generate well-branded interfaces and assets for Oversize, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key files:
- `README.md` — brand overview, content fundamentals, visual foundations, iconography
- `colors_and_type.css` — all tokens (colors, type, spacing, radii, shadows, motion) + semantic helper classes
- `assets/` — logo lockups in every color combination
- `preview/` — design system cards, one per sub-concept

Design rules at a glance:
- **Palette:** Red `#B51F3A`, Graphite `#3C3C3C`, Ash `#D9D9D9`, white, black. No gradients.
- **Type:** Sansa Pro (loaded from `fonts/`). Display is Black 900, lowercase, tight tracking. Available weights: 300 / 400 / 600 / 700 / 900.
- **Shape:** Square by default (2px radii). Signature offset shadow `6px 6px 0 0 graphite`.
- **Voice:** Lowercase, direct, confident. No emoji. "you" not "we."
- **One red per screen.** Red is the exclamation point.
- **Icons:** Lucide, stroke 2, monochrome (substitute — confirm with team).
