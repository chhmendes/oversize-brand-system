# Oversize Design System

> **oversize** — bold, confident, unmissable. A brand that literally wears its name: chunky lowercase letterforms, a two-tone palette that punches, and a flat-graphic sensibility. No gradients, no drop shadows, no polish-for-polish's-sake. Just big, clear statements.

---

## Index

| File / Folder | What's in it |
|---|---|
| `README.md` | You are here. Brand overview, content & visual foundations, iconography. |
| `colors_and_type.css` | All color + type CSS variables, plus semantic helper classes. Drop-in ready. |
| `SKILL.md` | Skill definition for portable use in Claude Code or other agents. |
| `assets/` | Logo variants (all 5 lockups provided), background swatch samples. |
| `preview/` | Design-system cards shown in the Design System tab (one card per sub-concept). |
| `fonts/` | Sansa Pro — Light (300), Normal (400), SemiBold (600), Bold (700), Black (900). |
| `ui_kits/` | _(not created — no product codebase/Figma was provided; see "What's missing" below)._ |
| `slides/` | _(not created — no deck template provided)._ |

## What was provided
Only **five logo lockups**, plus a short palette/type note:
- `uploads/Oversize 2026 (original).png` — red "over" + graphite "size" on white
- `uploads/Oversize 2026 (red).png` — red logo on light gray
- `uploads/Oversize 2026 (all red).png` — gray logo on red
- `uploads/Oversize 2026 (gray).png` — graphite logo on light gray
- `uploads/Oversize 2026 (all gray).png` — light-gray logo on graphite

No codebase, no Figma, no product screens, no sample copy. Everything past the wordmark + three-color palette below is an extrapolation from the visual DNA of the mark itself — reasonable defaults that match its personality, flagged where they're guesses.

## Sources
- Brand palette (from user): Red `#B51F3A`, Graphite `#3C3C3C`, Light gray `#D9D9D9`, white type on dark.
- Typeface (from user): **Sansa Pro** — `.otf` files supplied and loaded locally from `fonts/`. Available weights: 300 Light, 400 Normal, 600 SemiBold, 700 Bold, 900 Black. (No italics, no 500/800 — tokens fall back to the nearest available weight.)

---

## Content fundamentals

> _Note: no product copy was provided. This section captures the tone we should adopt based on the visual identity — treat as a starting point and correct as real copy appears._

**Voice:** direct, confident, a little cheeky. The brand is called "oversize" — its whole posture is "go big or go home." Copy should match: short sentences, strong verbs, no hedging.

**Casing:** **lowercase is the brand's default**. The wordmark is lowercase; display headlines should follow suit. Body copy uses sentence case. ALL CAPS is reserved for small utility labels (section tags, button labels when space permits) and should always ship with tracking (`--tr-label`).

**Pronouns:** second person ("you"). Never "we" as the subject of a brag. When the brand refers to itself, "oversize" stays lowercase even at the start of a sentence.

**Emoji:** no. The visual system is graphic and disciplined; emoji undercut it. Use iconography from the chosen set instead (see Iconography below).

**Examples (suggested voice — replace with real copy when available):**
- Hero: _"bigger is the point."_
- CTA: _"go oversize"_ / _"see it big"_ / _"no small talk"_
- Section tag: `01 / THE IDEA`
- Error: _"that didn't fit. try again."_ (lowercase, short, honest)
- Empty state: _"nothing here yet. go make something oversize."_

**Avoid:** corporate filler ("leverage," "solutions," "empower"), exclamation points (the typography does the shouting), cute wordplay that isn't scale-related.

---

## Visual foundations

### Color
Three colors do most of the work. Everything else is restraint.

| Token | Hex | Use |
|---|---|---|
| `--ov-red` | `#B51F3A` | Brand accent. Buttons, links, the "over" in a lockup, a single focal element per screen. Never a background for long-form reading. |
| `--ov-graphite` | `#3C3C3C` | Primary dark surface, primary text on light, dominant "size" word in lockup. |
| `--ov-ash` | `#D9D9D9` | Neutral light surface, quiet text on dark, divider lines. |
| `--ov-white` / `--ov-black` | `#FFFFFF` / `#0A0A0A` | Page whites and the deepest inkable dark. |

**Rules**:
- **Never layer red on graphite for text** — contrast is borderline. Use red on white/ash, or ash/white on graphite.
- **One red per screen.** Red is the exclamation point. If everything is red, nothing is.
- Full-bleed red panels are allowed and encouraged for hero moments (see `logo-gray-on-red` lockup).
- No gradients. The brand is flat.

### Type
**Display: heavy, rounded, lowercase.** The wordmark sets the rule — display type is Sansa Pro Black (900), lowercase, tight tracking (`-0.03em`), line-height `1.02`. Headlines should feel like they're bumping into each other.

**Body: Sansa Pro Normal (400) at 16–18px, line-height 1.6.** Workhorse-neutral so the display can shout.

**Labels: Sansa Pro Bold (700), uppercase, `0.12em` tracking, 12px.** Small all-caps tags are the only uppercase in the system.

**Mono: JetBrains Mono.** For code, numeric tables, ticket/serial-style accents.

Full tokens in `colors_and_type.css`. A type specimen card lives in `preview/type-scale.html`.

### Spacing & layout
- **4px base grid.** Tokens `--sp-1` (4px) through `--sp-10` (128px).
- **Generous negative space around display.** The logo itself sits in ~25% padding; treat display headlines the same.
- **Hard left alignment.** The wordmark is left-aligned and stacked; prefer that over centered comps.
- **Grid: 12-column on desktop, 4-column on mobile.** Gutter `--sp-5` (24px), margin `--sp-7` (48px) desktop / `--sp-4` mobile.

### Backgrounds
- **Flat solids first.** White, graphite, red, ash — any of the four, full-bleed.
- **No photography defaults** (none provided). When photography is used, treat as editorial b&w or heavy red/graphite duotone to stay on-palette.
- **No noise, no gradients, no textures** in v1. The brand is graphic; noise would muddy it.

### Borders, radii & shadows
- **Square by default.** `--r-0` / `--r-1` (2px) for most components. `--r-3` (8px) for friendlier cards. Reserve `--r-pill` for tags and avatars.
- **2px borders in graphite or red.** Hairlines feel too timid for this brand.
- **Signature offset shadow**: `--sh-hard` = `6px 6px 0 0 graphite`. Use sparingly on CTAs and cards to reinforce the chunky, poster-like feel. A red variant (`--sh-hard-red`) exists for dark surfaces.
- Soft blur shadows (`--sh-1`..`--sh-3`) exist but should be rare — this isn't a material-design system.

### Motion
- **Short, punchy, direct.** Durations 120–360ms.
- **Ease-punch** (`cubic-bezier(0.34, 1.56, 0.64, 1)`) for UI that should feel assertive (buttons on press, modal entrances).
- **Ease-out** for everything ambient.
- **No looping ambient animations.** Nothing that shimmers or pulses.

### Hover & press
- **Hover (on red):** shift to `--ov-red-bright` (`#D42848`, slightly warmer + lighter).
- **Hover (on graphite):** shift to `#4D4D4D` or add a 2px red outline.
- **Press:** scale `0.97` + shift to `--ov-red-deep`/`#2A2A2A`. ~100ms, ease-punch.
- **Focus ring:** 3px red outline with 2px offset. Accessible and on-brand.

### Transparency & blur
- **Use transparency for overlays only** — modal scrims at `rgba(60,60,60,0.75)`, bottom-sheet drags, etc.
- **No glass/blur surfaces in v1.** The brand reads as graphic poster, not iOS.

### Cards
- 2px solid border in `--ov-graphite` OR 8px solid `--sh-hard` offset shadow (pick one per context, don't mix).
- Radius `--r-3` (8px).
- White or ash fill on light backgrounds; graphite fill on red/dark backgrounds.

---

## Iconography

**No icon set was provided** with the brand materials. Recommended substitution:

- **Lucide** ([lucide.dev](https://lucide.dev)) — CDN-available, open source, 1.5px stroke by default. Its geometric-but-friendly feel pairs well with Rubik's rounded terminals. Weight: match the text weight around each icon; for 16px body, use 20px icons at stroke-width `2`.
- CDN link: `<script src="https://unpkg.com/lucide@latest"></script>` then `<i data-lucide="arrow-right"></i>`.

**Usage rules (proposed — confirm with brand team):**
- **Stroke only, no filled glyphs** (matches the flat graphic posture).
- **Monochrome** — inherit from `currentColor`. Red icons only on pure-accent contexts (standalone CTAs, status).
- **No emoji** anywhere in product UI, marketing, or docs.
- **Unicode dingbats** (→, ×, ✓) are fine as typographic punctuation inside copy, but for actionable icons use Lucide.
- **Logo is not an icon.** Never shrink the full wordmark below 48px wide — use a monogram (`O` in Rubik Black, red) for favicons and avatars instead.

**⚠️ Flag:** Lucide is a substitute. If the brand team has a custom icon set, drop it into `assets/icons/` and update this section.

---

## What's missing / next iterations

- **Product context.** No codebase, Figma, or screens were attached — so no UI kits (`ui_kits/`) or deck templates (`slides/`) were built. The system is foundational only. Once you share a product (web app, marketing site, deck template, etc.), UI kits become buildable.
- **Real copy samples.** The voice section is extrapolated from the visual identity. A few paragraphs of real marketing/product copy would let us tune the guidance.
- **Photography direction.** If oversize uses photography, share examples — we'll define a treatment (b&w? duotone? full-bleed editorial?).
- **Icon set confirmation.** Lucide is a placeholder; a custom set (or a different open set like Phosphor/Tabler) can be swapped in with no other system changes.

Questions? Open an issue or ping the team — this system should evolve with the product.
